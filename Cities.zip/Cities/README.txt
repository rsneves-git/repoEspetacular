Instruções para executar:

Aceder ao folder onde está o projecto:
> cd {path}\newApp
>npm install

Iniciar aplicação
> node server.js

Aceder ao url no browser
http://localhost:8080