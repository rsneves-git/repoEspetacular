var citiesApp = angular.module('mycitiesApp', []);


citiesApp.controller('citiesController', [function () {

    var _this = this;

    _this.showInputs = false;

    //searchFunction
    _this.getCities = function () {
        if (_this.nameCity) {
            _this.citiesList = _this.citiesList.filter(city => city.name === _this.nameCity);
        }
        if (_this.temperature) {
            _this.citiesList = _this.citiesList.filter(city => city.maxTemp === _this.temperature);
        }
    }

    
    //addCityFunction
    _this.addCity = function () {
        if (_this.newcity) {
            _this.newcity.name = '';
            _this.newcity.maxTemp = '';
            _this.newcity.startDay = '';
            _this.newcity.startNigth = '';
        }
        _this.showInputs = true;
    }
    
    //saveNewCityFunction and validation
    _this.saveNewCity = function () {
        _this.erroMessage = '';
        _this.cityName = '';

        if (_this.newcity && _this.newcity.name && _this.newcity.maxTemp && _this.newcity.startDay && _this.newcity.startNigth) {
            _this.cityName = _this.citiesList.find(city => city.name === _this.newcity.name);
            _this.changeFormatDate();
            if (_this.newcity.maxTemp > 60) {
                _this.erroMessage = "A temperatura máxima não poderá ultrapassar os 60 graus.";
            }
            else if (_this.newcity.startDay === _this.newcity.startNigth) {
                _this.erroMessage = "O horário de início de dia e de início de noite não poderá ser o mesmo, por favor retifique.";
            }
            else if (_this.newcity.name === _this.cityName) {
                _this.erroMessage = "A cidade já se encontra na lista de resultados.";
            }
            else if (_this.erroMessage.length == 0) {
                _this.citiesList.push(_this.newcity);
                _this.generateChar();
                _this.showInputs = false;
            }
        } else {
            _this.erroMessage = "Para adicionar uma nova cidade, terá de preencher todos os campos de preenchimento obrigatório.";
        }
    }

    _this.cancelNewCity = function () {
        _this.erroMessage = '';
        _this.showInputs = false;

    }

    //changeDate start and End
    _this.changeFormatDate = function () {
        if (_this.newcity.startDay.includes(':')) {
            _this.newcity.startDay = _this.newcity.startDay.replace(':', 'h');
            if (_this.newcity.startNigth.includes(':')) {
                _this.newcity.startNigth = _this.newcity.startNigth.replace(':', 'h');
            }
        }
        if (_this.newcity.startDay.length == 4) {
            _this.newcity.startDay = '0' + _this.newcity.startDay;
        }
        if (_this.newcity.startNigth.length == 4) {
            _this.newcity.startNigth = '0' + _this.newcity.startNigth;
        }
    }



    //results List
    _this.citiesList =
        [
            {
                "id": 0,
                "name": "Porto",
                "maxTemp": 23,
                "startDay": "06h58",
                "startNigth": "20h14"
            },
            {
                "id": 1,
                "name": "Coimbra",
                "maxTemp": 27,
                "startDay": "06h58",
                "startNigth": "20h12"
            },
            {
                "id": 2,
                "name": "Guarda",
                "maxTemp": 25,
                "startDay": "06h53",
                "startNigth": "20h08"
            },
            {
                "id": 3,
                "name": "Leiria",
                "maxTemp": 24,
                "startDay": "07h00",
                "startNigth": "20h13"
            },
            {
                "id": 4,
                "name": "Viseu",
                "maxTemp": 27,
                "startDay": "06h55",
                "startNigth": "20h11"
            }
        ];




    _this.sortColumn = 'name';
    _this.reverseSort = false;

    //ordenacao tabela
    _this.sortCities = function (column) {
        _this.reverseSort = (_this.sortColumn === column) ? !_this.reverseSort : false;
        _this.sortColumn = column;
        _this.sortArray();
        _this.generateChar();
    }

    _this.sortArray = function () {
        _this.citiesList.sort(function (a, b) {
            if (_this.reverseSort) {
                return a[_this.sortColumn] < b[_this.sortColumn];
            }
            else {
                return a[_this.sortColumn] > b[_this.sortColumn];
            }
        });
    }
    

    _this.getCitiesIcon = function (column) {
        if (_this.sortColumn == column) {
            return _this.reverseSort ? 'glyphicon glyphicon-menu-down' : 'glyphicon glyphicon-menu-up';
        }
        return '';
    }
   


    /*Chart*/
    _this.generateChar = function () {
        var ctx = document.getElementById('myCities').getContext('2d');
        var myCities = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: _this.citiesList.map(city => city.name),
                datasets: [{
                    label: 'Graus',
                    data: _this.citiesList.map(city => city.maxTemp),
                    backgroundColor: [
                        '#1b2c4c',
                        '#32629c',
                        '#A85047',
                        '#145C34',
                        '#69313C',
                        '#8F6211',
                        '#6a8aca',
                        '#7d99d1',
                        '#4F3609',
                        '#CF6B2D'
                    ],

                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }],
                    xAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                },
                title: {
                    text: 'Temperaturas máximas (graus)',
                    display:true
                },
                legend: {
                    display: false
                }

            }
        });
    }

    _this.sortArray();
    _this.generateChar();
    

}]);





